
def get_door_sensor_id():
    pass

def get_motion_sensor_id():
    pass

def get_water_sensor_id():
    pass

def get_cust_pk():
    pass

def get_spn():
    pass

def get_nimbits_credentials():
    pass

def get_beehive_credentials():
    pass

def get_openremote_credentials():
    pass
